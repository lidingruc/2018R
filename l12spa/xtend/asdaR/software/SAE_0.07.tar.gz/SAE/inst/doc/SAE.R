###################################################
### chunk number 1: 
###################################################
#Function to compute the AEMSE
AEMSE<-function(est, true)
{
	m<-length(est)
	x<-formatC(sum((est-true)^2)/m, digits=4)
	return(x)
}

method<-c("Pi estimator", "GREG", "Synthetic", "LMM (Area)", "LMM (Unit)", 
  "Composite", "EBLUP (Area) - ML", "EBLUP (Area) - REML", 
"SEBLUP (Area) - ML", "SEBLUP (Area) - REML",
"Bayesian (ran.eff.) - mean", "Bayesian (ran.eff.) -  median", 
"Bayesian (r.e.+CAR) - mean", "Bayesian (r.e.+CAR) - median", 
"Bayesian (CAR) - mean", "Bayesian (CAR) - median",
"Bay.unit (ran.eff.) - mean", "Bay.unit (ran.eff.) -  median", 
"Bay.unit (r.e.+CAR) - mean", "Bay.unit (r.e.+CAR) - median", 
"Bay.unit (CAR) - mean", "Bay.unit (CAR) - median")
aemse<-rep(0, length(method))


###################################################
### chunk number 2: 
###################################################
library(SAE)
data(seblup)


###################################################
### chunk number 3: 
###################################################
library(SAE)
data(seblup)
#load("seblup.RData")
plot(Waree, xlab="Area", ylab="Area", pch=".")


###################################################
### chunk number 4: 
###################################################
smmry<-data.frame(region=1:m)
smmry$Ytot<-as.vector(by(y[,2], y[,1], sum))
smmry$Ymean<-as.vector(by(y[,2], y[,1], mean))
smmry$Xtot<-as.vector(by(X[,1], X[,2], sum))
smmry$Xmean<-as.vector(by(X[,1], X[,2], mean))
smmry$N<-as.vector(by(y[,2], y[,1], length))
smmry$n<-n

smmry$YStot<-as.vector(by(S[,2], S[,1], sum))
smmry$YSmean<-as.vector(by(S[,2], S[,1], mean))
smmry$XStot<-as.vector(by(XS[,1], XS[,2], sum))
smmry$XSmean<-as.vector(by(XS[,1], XS[,2], mean))

smmry$sigma2e<-as.vector(by(y[,2], y[,1], var))
smmry$sigma2eS<-as.vector(by(S[,2], S[,1], var))
library(xtable)

l<-c(1,3,5,6,7,9, 11,12,13)
xt<-xtable(smmry[,l], align="r|c|ccc|ccc|cc", 
  caption="Summary of the different areas simulated. See text for details.", 
  label="tab:smmry")


###################################################
### chunk number 5: 
###################################################
print(xt, floating=TRUE, type="latex", table.placement="htb!")


###################################################
### chunk number 6: 
###################################################
probs<-1/N
probs<-1-(1-probs)^n
w<-1/probs

#Estimated mean
piest<-by(S[,2], S[,1], sum)
piest<-as.vector(piest)*w/(n*w)

#Actual means
actmeans<-smmry$Ymean


###################################################
### chunk number 7: 
###################################################
plot(piest, actmeans, xlab="Pi-estimator", ylab="True means")
abline(coef=c(0,1))


###################################################
### chunk number 8: 
###################################################
#INTERCEP would be used if an intercept is used in the linear model
#
d<-data.frame(Y=S[,2], X=XS[,1], INTERCEP=1) 

#Weights for each individual
#wgreg<-as.vector(unlist(apply(data.frame(w, n), 1, function(X){rep(X[1], 
#  each=X[2])})))
wgreg<-w[XS[,2]]
#Fit weighted linear model
lmgreg<-lm(formula = Y ~ -1+INTERCEP+X, data = d, weights = wgreg)
lmgreg

#  \hat\beta \overline{X}
p1<-as.vector(predict(lmgreg, data.frame(INTERCEP=1, X=Xpop[,2])))
# \hat\beta X_ij
p2<-as.vector(predict(lmgreg,  data.frame(INTERCEP=1, X=XS[,1])))
#w_ij * (y_ij - \hat\beta X_ij)
p2<-(S[,2]-p2)*wgreg
p2<-as.vector(by(p2, S[,1], sum))/(n*w)
gregest<-p1+p2

#gregest<-piest+p1-as.vector(by(p2, S[,1], sum))


###################################################
### chunk number 9: 
###################################################
plot(gregest, actmeans, xlab="GREG estimator", ylab="Actual means")
abline(coef=c(0,1))


###################################################
### chunk number 10: 
###################################################
#Synthetic estimator at the area level model

synthd<-data.frame(Y=ydir1, COV=Xpop[,2])
synthmodel<-lm(Y~1+COV, data=synthd)
synthmodel

synthest<-predict(synthmodel, data.frame(COV=Xpop[,2]) )


###################################################
### chunk number 11: 
###################################################
plot(synthest, actmeans, xlab="Synthetic estimator", ylab="Actual means")
abline(coef=c(0,1))


###################################################
### chunk number 12:  eval=FALSE
###################################################
## library(nlme)
## #d<-data.frame(Y=ydir1, X=Xpop[,2], region=1:m)
## #lmm<-lme(Y~1+X, random=~1|region, data=d, method="ML")
## 
## d<-data.frame(Y=ydir1, X=Xpop[,2], region=1:m, VARSTR=1/n)
## vf <- varFixed(~VARSTR)
## vf <- Initialize(vf, d)
## lmm<-lme(Y~1+X, random=~1|region, data=d, weights=vf)
## 
## lmm


###################################################
### chunk number 13:  eval=FALSE
###################################################
## plot(fitted(lmm), actmeans, xlab="True means", ylab="Fitted means using a LMM")
## abline(coef=c(0,1))


###################################################
### chunk number 14: 
###################################################
library(nlme)

dunit<-data.frame(Y=S[,2], X=XS[,1], region=S[,1])
lmmunit<-lme(Y~1+X, random=~1|region, data=dunit, method="ML")
#ranef(lmmunit)
lmmunit

yunit<-data.frame(X=X[,1], region=X[,2])
ypred<-as.vector(predict(lmmunit, yunit))
lmmunitest<-as.vector( by(ypred, yunit$region, mean) )


###################################################
### chunk number 15: 
###################################################
plot(lmmunitest, actmeans, xlab="True means", 
  ylab="Fitted means using a LMM (UNIT level)")
abline(coef=c(0,1))


###################################################
### chunk number 16:  eval=FALSE
###################################################
## raneflmm<-as.vector(ranef(lmm))
## raneflmmunit<-as.vector(ranef(lmmunit))


###################################################
### chunk number 17:  eval=FALSE
###################################################
## plot(raneflmm[,1], raneflmmunit[,1], xlab="Random effects (area level model)", 
##   ylab="Random effects (unit level model)")
## abline(coef=c(0,1))


###################################################
### chunk number 18: 
###################################################
sigma2u<-exp(as.numeric(attr(lmmunit$apVar, "Pars"))[1])
sigma2e<-exp(as.numeric(attr(lmmunit$apVar, "Pars"))[2])
gamma<-sigma2u/(sigma2u+sigma2e/n)
compest<-gamma*synthest+(1-gamma)*piest


###################################################
### chunk number 19: 
###################################################
plot(compest, actmeans, xlab="True means",
  ylab="Composite estimator")
abline(coef=c(0,1))


###################################################
### chunk number 20:  eval=FALSE
###################################################
## #Load R files
## w<-getwd()
## setwd("../../R")
## f<-dir()
## print(f)
## for (i in f) {source(i)}
## setwd(w)


###################################################
### chunk number 21: 
###################################################
#EBLUP using ML estimation
eblupml<-EBLUP.area(ydir1, Xpop, vardir, m)

#EBLUP using ML estimation
eblupreml<-EBLUP.area(ydir1, Xpop, vardir, m, method="REML")


###################################################
### chunk number 22: 
###################################################
plot(eblupml$EBLUP, actmeans, xlab="EBLUP estimator", ylab="Actual means", 
  pch=20)
points(eblupreml$EBLUP, actmeans, pch=2)
legend(20, 140, c("EBLUP ML", "EBLUP REML"), pch=c(20, 2))
abline(coef=c(0,1))


###################################################
### chunk number 23: 
###################################################
#SEBLUP using ML estimation
seblupml<-SEBLUP.area(ydir1, Xpop, vardir, m, W)

#SEBLUP using ML estimation
seblupreml<-SEBLUP.area(ydir1, Xpop, vardir, m, W, method="REML")


###################################################
### chunk number 24: 
###################################################
plot(seblupml$SEBLUP, actmeans, xlab="SEBLUP estimator", ylab="Actual means",
  pch=20)
points(seblupreml$SEBLUP, actmeans, pch=2)
legend(20, 140, c("SEBLUP ML", "SEBLUP REML"), pch=c(20, 2))
abline(coef=c(0,1))


###################################################
### chunk number 25: 
###################################################
plot(eblupreml$EBLUP, actmeans, xlab="(S)EBLUP estimator", ylab="Actual means",
  pch=20)
points(seblupreml$SEBLUP, actmeans, pch=2)
legend(20, 140, c("EBLUP REML", "SEBLUP REML"), pch=c(20, 2))
abline(coef=c(0,1))


###################################################
### chunk number 26: 
###################################################
#par(mfrow=c(1,2))
plot(eblupreml$EBLUP, xlab="Region", ylab="Value/Estimate",
  pch=20, ylim=c(0, 180))
points(seblupreml$SEBLUP, pch=2)
points(actmeans)
legend(1, 180, c("EBLUP REML", "SEBLUP REML", "True mean"), pch=c(20, 2, 1))

for(i in 1:m)
	lines(c(i,i), c(seblupreml$SEBLUP[i], actmeans[i]), col="red")

legend(18, 180, "Distance SEBLUP-True mean", lty=1, col="red", cex=.85)



###################################################
### chunk number 27:  eval=FALSE
###################################################
## #EBLUP using ML estimation
## seblupmlu<-SEBLUP.unit(S, XS, Xpop, ZS, m, W)
## 
## #EBLUP using ML estimation
## seblupremlu<-SEBLUP.unit(S, XS, Xpop, ZS, m, W, method="REML")


