#
#Auxiliary function needed by areal SEBLUP
#Written by N. Salvati and modified by V. Gómez-Rubio
#

#Log-likelihood of rho and sigma.v
logl<-function(x)
{
	rhospat<-x[1]
        sigma.v<-x[2]
        I<-diag(1,m)
        V<-sigma.v*(solve((I-rhospat*W)%*%(I-rhospat*t(W))))+vardir[,1]*diag(1,m) #variance covariance matrix
        b.stim.spat<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir1[,1]
        ee<-eigen(V)

	#log-likelihood
        (-1)*(((-0.5)*m*log(2*pi))-((0.5)*sum(log(ee$value)))-((0.5)*t(ydir1[,1]-(Xpop)%*%b.stim.spat)%*%solve(V)%*%(ydir1[,1]-(Xpop)%*%b.stim.spat)))
}




# Gradient function (partial derivatives)
grr<-function(x)
{
	rhospat<-x[1]
	sigma.v<-x[2]

	derRho<-2*W%*%(I-rhospat*t(W))
	derSigma<-solve((I-rhospat*W)%*%(I-rhospat*t(W)))
	derVRho<-sigma.v*(derSigma%*%derRho%*%derSigma)

	V<-matrix(0,m,m)
	V<-sigma.v*(solve((I-rhospat*W)%*%(I-rhospat*t(W))))+(diag(1,m)*vardir[,1])

	b.s<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir1[,1]

	s<-matrix(0,2,1)
	#Score function
	s[1,1]<-((-0.5)*sum(diag(solve(V)%*%derSigma)))+((0.5)*(t(ydir1[,1]-Xpop%*%b.s)%*%(solve(V)%*%derSigma%*%solve(V))%*%(ydir1[,1]-Xpop%*%b.s)))

	s[2,1]<-((-0.5)*sum(diag(solve(V)%*%derVRho)))+((0.5)*(t(ydir1[,1]-Xpop%*%b.s)%*%(solve(V)%*%derVRho%*%solve(V))%*%(ydir1[,1]-Xpop%*%b.s)))

	return(c(s[1,1],s[2,1]))
}
