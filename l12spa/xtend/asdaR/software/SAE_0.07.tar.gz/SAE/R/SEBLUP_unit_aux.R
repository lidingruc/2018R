#
#Auxiliary function needed by unit SEBLUP
#Written by N. Salvati and modified by V. Gómez-Rubio
#

#Log-likelihood of rho, sigma.v and  sigma.e
logl.unit<-function(x){
                  rhospat<-x[1]
                  sigma.v<-x[2]
                  sigma.e<-x[3]
                
                  I<-diag(1,m)
                  V<-sigma.v*Z%*%(solve((I-rhospat*W)%*%(I-rhospat*t(W))))%*%t(Z)+sigma.e*diag(1,nc)
                  b.stim.spat<-solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)%*%S[,2]
                  ee=eigen(V)
                  (-1)*((-0.5)*sum(log(ee$value))-(0.5)*t(S[,2]-XS%*%b.stim.spat)%*%solve(V)%*%(S[,2]-XS%*%b.stim.spat)-(nc/2)*log(2*pi))}

# Gradient function (partial derivatives)
grr.unit<-function(x){  rhospat<-x[1]
                  sigma.v<-x[2]
                  sigma.e<-x[3]
                  B=Z%*%solve((I-rhospat*W)%*%(I-rhospat*t(W)))%*%t(Z)
                  C=sigma.v*Z%*%((-1)*solve((I-rhospat*W)%*%(I-rhospat*t(W)))%*%(-2*W+2*rhospat*W%*%t(W))%*%solve((I-rhospat*W)%*%(I-rhospat*t(W))))%*%t(Z)
                  Inn=diag(1,nc)
                  V<-matrix(0,nc,nc)
                  s<-matrix(0,3,1)
                  I<-diag(1,m)
                  V<-sigma.v*Z%*%(solve((I-rhospat*W)%*%(I-rhospat*t(W))))%*%t(Z)+sigma.e*diag(1,nc)
                  b.s<-solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)%*%S[,2]
                  s[1,1]<-((-0.5)*sum(diag(solve(V)%*%B)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(solve(V)%*%B%*%solve(V))%*%(S[,2]-XS%*%b.s)))  
                  s[2,1]<-((-0.5)*sum(diag(solve(V)%*%Inn)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(solve(V)%*%Inn%*%solve(V))%*%(S[,2]-XS%*%b.s)))
                  s[3,1]<-((-0.5)*sum(diag(solve(V)%*%C)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(solve(V)%*%C%*%solve(V))%*%(S[,2]-XS%*%b.s)))  
                  c(s[1,1],s[2,1],s[3,1])
}
