#Spatial EBLUP ML procedure SAR spatial process
#Written by N. Salvati and modified by V. Gómez-Rubio
#


#to obtain the starting point or we can stop at "ottimo" to obtain the estimation of rho and sigma2u
#W is the standardized proximity matrix
#rhospat is the autoregressive coefficient
#sigma2u is the variance component


SEBLUP.area<-function(ydir, Xpop, vardir, m, W, tol=10e-5, maxiter=50, method="ML", init=NULL)
{

        res<-switch(method,
                ML = SEBLUP.area.ML(ydir, Xpop, vardir, m, W, tol, maxiter,init),
                REML = SEBLUP.area.REML(ydir, Xpop, vardir, m, W, tol, maxiter,init)
        )

        if(is.null(res))
                print("Method should be ML or REML\n")

        return(res)
}



#The SEBLUP starts here
SEBLUP.area.ML<-function(ydir, Xpop, vardir, m, W, tol, maxiter,init)
{

if(is.null(init))
{
limiti<-eigen(W)
sup<-1/max(limiti$value) #upper limit
inf<-1/min(limiti$value) #low limit
ottimo<-constrOptim(c(0.1,100),logl,grr,method="Nelder-Mead",ui=rbind(c(-1,0),c(1,0),c(0,1)),ci=c(-sup,inf,0), control = list(trace=TRUE))
}
else
{
ottimo<-list(par=init)
}
#from here it starts the scoring method with starting point these obteined from "Nelder-Mead" alghoritm
I<-diag(1,m)
rho.stim.S<-0
sigma2.u.stim.S<-0
sigma2.u.stim.S[1]<-ottimo$par[2]
rho.stim.S[1]<-ottimo$par[1]

k<-0
diff.S<-1
while ( (diff.S>tol) && (k<maxiter) )
{
	k<-k+1

	derRho<-2*W%*%(I-rho.stim.S[k]*t(W))
	derSigma<-solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))
	derVRho<-sigma2.u.stim.S[k]*(derSigma%*%derRho%*%derSigma)

	V<-matrix(0,m,m)
	V<-(sigma2.u.stim.S[k]*(solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))))+(diag(1,m)*vardir[,1])

	b.s<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir[,1]

	s<-matrix(0,2,1)

	s[1,1]<-((-0.5)*sum(diag(solve(V)%*%derSigma)))+((0.5)*(t(ydir[,1]-Xpop%*%b.s)%*%(solve(V)%*%derSigma%*%solve(V))%*%(ydir[,1]-Xpop%*%b.s)))  
	s[2,1]<-((-0.5)*sum(diag(solve(V)%*%derVRho)))+((0.5)*(t(ydir[,1]-Xpop%*%b.s)%*%(solve(V)%*%derVRho%*%solve(V))%*%(ydir[,1]-Xpop%*%b.s))) #score function

	#Idev is the information matrix
	Idev<-matrix(0,2,2)
	Idev[1,1]<-(0.5)*sum(diag((solve(V)%*%derSigma%*%solve(V)%*%derSigma)))
	Idev[1,2]<-(0.5)*sum(diag((solve(V)%*%derSigma%*%solve(V)%*%derVRho)))
	Idev[2,1]<-(0.5)*sum(diag((solve(V)%*%derVRho%*%solve(V)%*%derSigma)))
	Idev[2,2]<-(0.5)*sum(diag((solve(V)%*%derVRho%*%solve(V)%*%derVRho)))

	par.stim<-matrix(0,2,1)
	par.stim[1,1]<-sigma2.u.stim.S[k]
	par.stim[2,1]<-rho.stim.S[k]

	stime.fin<-matrix(0,2,1)
	stime.fin<-par.stim+solve(Idev)%*%s #the scoring procedure
	sigma2.u.stim.S[k+1]<-stime.fin[1,1]
	rho.stim.S[k+1]<-stime.fin[2,1]
	diff.S<-abs(stime.fin[1,1]-par.stim[1,1])
}


V<-matrix(0,m,m)
V<-(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))+(diag(1,m)*vardir[,1])

G<-(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))

Bstim<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir[,1]

m1<-diag(1,m)

#Spatial EBLUP
randeff<-m1%*%G%*%solve(V)%*%(ydir[,1]-(Xpop%*%Bstim))#Area effects
thetaEBLUPSpat<-Xpop%*%Bstim+randeff #m1%*%G%*%solve(V)%*%(ydir[,1]-(Xpop%*%Bstim))
varbeta<-solve(t(Xpop)%*%solve(V)%*%Xpop)

#to estimate MSE for each small area
#g1
g1sp<-matrix(0,m,1)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
	m1[i]<-1
	g1sp[i]<-t(m1)%*%(G-G%*%solve(V)%*%G)%*%m1
}

#g2
g2sp<-matrix(0,m,1)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
	m1[i]<-1
	g2sp[i]<-(Xpop[i,]-t(m1)%*%G%*%solve(V)%*%Xpop)%*%solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop[i,]-t(m1)%*%G%*%solve(V)%*%Xpop)
}

#g3

derRho<-2*W%*%(I-rho.stim.S[k+1]*t(W))
derSigma<-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))
derVRho<-sigma2.u.stim.S[k+1]*(derSigma%*%derRho%*%derSigma)
Idev<-matrix(0,2,2)
Idev[1,1]<-(0.5)*sum(diag((solve(V)%*%derSigma%*%solve(V)%*%derSigma)))
Idev[1,2]<-(0.5)*sum(diag((solve(V)%*%derSigma%*%solve(V)%*%derVRho)))
Idev[2,1]<-(0.5)*sum(diag((solve(V)%*%derVRho%*%solve(V)%*%derSigma)))
Idev[2,2]<-(0.5)*sum(diag((solve(V)%*%derVRho%*%solve(V)%*%derVRho)))

g3sp<-matrix(0,m,1)
g3spgrad<-matrix(0,2,m)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
	m1[i]<-1
	A<-(I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))
	AA<-2*rho.stim.S[k+1]*(W%*%t(W))-2*W
	g3spgrad[1,]<-t(m1)%*%(solve(A)%*%solve(V)+G%*%((-1)*solve(V)%*%solve(A)%*%solve(V)))
	g3spgrad[2,]<-t(m1)%*%((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%solve(V)+G%*%((-1)*solve(V)%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%solve(V)))
	g3sp[i]<-sum(diag(g3spgrad%*%V%*%t(g3spgrad)%*%solve(Idev)))
}


#bias
bdist<-matrix(0,2,1)
btr<-matrix(0,2,1)
gradg1sp<-matrix(0,2,1)
distorsionesp<-matrix(0,m,1)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
	m1[i]<-1

	A<-(I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))
	AA<-2*rho.stim.S[k+1]*(W%*%t(W))-2*W

	gradg1sp[1,]<-t(m1)%*%(solve(A)-((solve(A)%*%solve(V)%*%G)+(G%*%((-1)*solve(V)%*%solve(A)%*%solve(V))%*%G)+(G%*%solve(V)%*%solve(A))))%*%m1
	gradg1sp[2,]<-t(m1)%*%((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%AA%*%solve(A)))-((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%AA%*%solve(A)))%*%solve(V)%*%G+(G%*%((-1)*solve(V)%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%AA%*%solve(A)))%*%solve(V))%*%G)+(G%*%solve(V)%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%AA%*%solve(A))))))%*%m1  

	btr[1,]<-sum(diag(solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%((-1)*solve(V)%*%solve(A)%*%solve(V))%*%Xpop))
	btr[2,]<-sum(diag(solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%((-1)*solve(V)%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%AA%*%solve(A)))%*%solve(V))%*%Xpop))

	bdist<-(1/(m*2))*(solve(Idev)%*%btr)
	distorsionesp[i,1]<-t(bdist)%*%gradg1sp
}

#estimated MSE
msestimsp<-g1sp-distorsionesp+g2sp+2*g3sp


#Return results
list(SEBLUP=thetaEBLUPSpat, beta=Bstim, sigma2u=sigma2.u.stim.S[k+1], 
  rho=rho.stim.S[k+1], g1=g1sp, g2=g2sp, g3=g3sp, mse=msestimsp, 
  randeff=randeff, varbeta=varbeta, varsigmarho=solve(Idev))

}





SEBLUP.area.REML<-function(ydir, Xpop, vardir, m, W, tol, maxiter,init)
{

I<-diag(1,m)

if(is.null(init))
{
limiti<-eigen(W)
sup<-1/max(limiti$value) #upper limit
inf<-1/min(limiti$value) #low limit
ottimo<-constrOptim(c(0.1,100),logl,grr,method="Nelder-Mead",ui=rbind(c(-1,0),c(1,0),c(0,1)),ci=c(-sup,inf,0), control = list(trace=TRUE))
}
else
{
	ottimo<-list(par=init)
}

rho.stim.S<-0
sigma2.u.stim.S<-0
sigma2.u.stim.S[1]<-ottimo$par[2]
rho.stim.S[1]<-ottimo$par[1]

k<-0
diff.S<-1

while ( (diff.S>tol) && (k<maxiter) )
{
	k<-k+1

	derRho<-2*W%*%(I-rho.stim.S[k]*t(W))
	derSigma<-solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))
	derVRho<-sigma2.u.stim.S[k]*(derSigma%*%derRho%*%derSigma)

	V<-matrix(0,m,m)
	V<-(sigma2.u.stim.S[k]*(solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))))+(diag(1,m)*vardir[,1])

	P<-matrix(0,m,m)
	P<-solve(V)-(solve(V)%*%Xpop%*%(solve(t(Xpop)%*%solve(V)%*%Xpop))%*%t(Xpop)%*%solve(V))

	b.s<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir[,1]

	s<-matrix(0,2,1)
	s[1,1]<-((-0.5)*sum(diag(P%*%derSigma)))+((0.5)*(t(ydir[,1])%*%P%*%derSigma%*%P%*%ydir[,1]))  
	s[2,1]<-((-0.5)*sum(diag(P%*%derVRho)))+((0.5)*(t(ydir[,1])%*%P%*%derVRho%*%P%*%ydir[,1]))  

	Idev<-matrix(0,2,2)
	Idev[1,1]<-(0.5)*sum(diag((P%*%derSigma%*%P%*%derSigma)))
	Idev[1,2]<-(0.5)*sum(diag((P%*%derSigma%*%P%*%derVRho)))
	Idev[2,1]<-(0.5)*sum(diag((P%*%derVRho%*%P%*%derSigma)))
	Idev[2,2]<-(0.5)*sum(diag((P%*%derVRho%*%P%*%derVRho)))

	par.stim<-matrix(0,2,1)
	par.stim[1,1]<-sigma2.u.stim.S[k]
	par.stim[2,1]<-rho.stim.S[k]

	stime.fin<-matrix(0,2,1)
	stime.fin<-par.stim+solve(Idev)%*%s
	sigma2.u.stim.S[k+1]<-stime.fin[1,1]

	rho.stim.S[k+1]<-stime.fin[2,1]
	diff.S<-abs(stime.fin[1,1]-par.stim[1,1])
	
}

V<-matrix(0,m,m)
V<-(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))+(diag(1,m)*vardir[,1])

G<-(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))

Bstim<-solve(t(Xpop)%*%solve(V)%*%Xpop)%*%t(Xpop)%*%solve(V)%*%ydir[,1]
m1<-diag(1,m)

randeff<-m1%*%G%*%solve(V)%*%(ydir[,1]-(Xpop%*%Bstim))
thetaEBLUPSpatREML<-Xpop%*%Bstim+randeff #m1%*%G%*%solve(V)%*%(ydir[,1]-(Xpop%*%Bstim))
varbeta<-solve(t(Xpop)%*%solve(V)%*%Xpop)


g1spREML<-matrix(0,m,1)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
        m1[i]<-1
        g1spREML[i]<-t(m1)%*%(G-G%*%solve(V)%*%G)%*%m1
}



g2spREML<-matrix(0,m,1)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
        m1[i]<-1
        g2spREML[i]<-(Xpop[i,]-(t(m1)%*%G%*%solve(V)%*%Xpop))%*%(solve(t(Xpop)%*%solve(V)%*%Xpop))%*%t(Xpop[i,]-(t(m1)%*%G%*%solve(V)%*%Xpop))
}



derRho<-2*W%*%(I-rho.stim.S[k+1]*t(W))
derSigma<-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))
derVRho<-sigma2.u.stim.S[k+1]*(derSigma%*%derRho%*%derSigma)

Idev<-matrix(0,2,2)
Idev[1,1]<-(0.5)*sum(diag((P%*%derSigma%*%P%*%derSigma)))
Idev[1,2]<-(0.5)*sum(diag((P%*%derSigma%*%P%*%derVRho)))
Idev[2,1]<-(0.5)*sum(diag((P%*%derVRho%*%P%*%derSigma)))
Idev[2,2]<-(0.5)*sum(diag((P%*%derVRho%*%P%*%derVRho)))

g3spREML<-matrix(0,m,1)
g3spgrad<-matrix(0,2,m)
for (i in 1:m)
{
	m1<-matrix(0,m,1)
	m1[i]<-1
	A<-(I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))
	AA<-2*rho.stim.S[k+1]*(W%*%t(W))-2*W
	g3spgrad[1,]<-t(m1)%*%(solve(A)%*%solve(V)+G%*%((-1)*solve(V)%*%solve(A)%*%solve(V)))
	g3spgrad[2,]<-t(m1)%*%((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%solve(V)+G%*%((-1)*solve(V)%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%solve(V)))
	g3spREML[i]<-sum(diag(g3spgrad%*%V%*%t(g3spgrad)%*%solve(Idev)))
}

msestimspREML<-g1spREML+g2spREML+2*g3spREML


#Return results
list(SEBLUP=thetaEBLUPSpatREML, beta=Bstim, sigma2u=sigma2.u.stim.S[k+1],
  rho=rho.stim.S[k+1], g1=g1spREML, g2=g2spREML, g3=g3spREML, mse=msestimspREML,
  randeff=randeff, varbeta=varbeta, varsigmarho=solve(Idev))



}
