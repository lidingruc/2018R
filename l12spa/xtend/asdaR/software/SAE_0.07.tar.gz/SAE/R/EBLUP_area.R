EBLUP.area<-function(ydir, Xpop, vardir, m, tol=10e-5, maxiter=50, method="ML")
{

	res<-switch(method,
		ML = EBLUP.area.ML(ydir, Xpop, vardir, m, tol, maxiter),
		REML = EBLUP.area.REML(ydir, Xpop, vardir, m, tol, maxiter)
	)

	if(is.null(res))
		print("Method should be ML or REML\n")

	return(res)
}


#traditional EBLUB ML procedure, scoring algorithm.
EBLUP.area.ML<-function(ydir, Xpop, vardir, m, tol, maxiter)
{
	sigma2.u.stim<-0  #variance components
	sigma2.u.stim[1]<-5000000 #starting value
	k<-0

	diff<-tol+1	
	while ((diff>tol) & (k<maxiter))
	{
		k<-k+1

		V<-diag(1,m) #variances-covariances matrix
		for (i in 1:m) 
		{
			V[i,i]<-(sigma2.u.stim[k]+vardir[i,1])
		} #vardir is the mX1 vector of sampling variance
		
		Vinv<-solve(V)

		BETA<-solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%Vinv%*%ydir[,1] #ydir is the mX1 vector of direct (sampling) estimates
		sdev<-(-0.5)*sum(diag(Vinv))-(0.5)*t(ydir[,1]-(Xpop)%*%BETA)%*%((-1)*Vinv%*%Vinv)%*%(ydir[,1]-(Xpop)%*%BETA) #Xpop is the mXp matrix of p auxiliary variables
		Idev<-((0.5)*(sum(diag(Vinv%*%Vinv))))^(-1) #Idev is the inverse of information matrix
		sigma2.u.stim[k+1]<-sigma2.u.stim[k]+Idev*sdev #scoring algorithm
		diff<-abs(sigma2.u.stim[k+1]-sigma2.u.stim[k])
	}

	if (sigma2.u.stim[k+1]<0) 
		sigma2u<-0 
	else
		sigma2u<-sigma2.u.stim[k+1]

	V<-diag(1,m)
	G<-diag(1,m)*sigma2u
	for (i in 1:m) {V[i,i]<-(sigma2u+vardir[i,1])}

	Vinv<-solve(V)

	Bstim<-solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%Vinv%*%ydir[,1]
	m1<-diag(1,m)
	thetaEBLUP<-Xpop%*%Bstim+m1%*%G%*%Vinv%*%(ydir[,1]-(Xpop%*%Bstim)) #EBLUP estimator
	varbeta<-solve(t(Xpop)%*%solve(V)%*%Xpop)
	randeff<-m1%*%G%*%Vinv%*%(ydir[,1]-(Xpop%*%Bstim))#Estimate of the random effects

	sig<-Bstim/sqrt(diag(solve(t(Xpop)%*%Vinv%*%Xpop))) #significance of Beta estimates

	#to estimate MSE for each small area
	#g1
	g1<-diag((G-G%*%Vinv%*%G))
	#g2
	g2<-matrix(0,m,1)
	for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
	g2[i]<-(Xpop[i,]-t(m1)%*%G%*%Vinv%*%Xpop)%*%solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop[i,]-t(m1)%*%G%*%Vinv%*%Xpop)}

	Idev<-((0.5)*(sum(diag(Vinv%*%Vinv))))^(-1)
	#g3
	g3<-matrix(0,m,1)
	for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
	g3[i]<-(t(m1)%*%(Vinv+G%*%((-1)*Vinv%*%Vinv))%*%V%*%t((t(m1)%*%(Vinv+G%*%((-1)*Vinv%*%Vinv)))))*Idev}

	#the bias
	bdist<-0
	btr<-0
	gradg1<-0
	I<-diag(1,m)
	distorsione<-matrix(0,m,1)
	for (i in 1:m) 
	{
		m1<-matrix(0,m,1)
		m1[i]<-1
		gradg1<-t(m1)%*%(I-((I%*%Vinv%*%G)+(G%*%((-1)*Vinv%*%I%*%Vinv)%*%G)+(G%*%Vinv%*%I)))%*%m1
		btr<-sum(diag(solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%((-1)*Vinv%*%I%*%Vinv)%*%Xpop))
		bdist<-(1/(m*2))*Idev*btr
		distorsione[i,1]<-bdist*gradg1
	}

	#estimated MSE
	msestim<-g1-distorsione+g2+2*g3


#	list(beta=Bstim, betasig=sig, EBLUP=thetaEBLUP,g1=g1, g2=g2, g3=g3, 
#		MSE=msestim)
	list(EBLUP=thetaEBLUP, beta=Bstim, sigma2u=sigma2.u.stim[k+1],
  g1=g1, g2=g2, g3=g3, mse=msestim, randeff=randeff, varbeta=varbeta)



}


EBLUP.area.REML<-function(ydir, Xpop, vardir, m, tol, maxiter)
{
	sigma2.u.stim<-0
	sigma2.u.stim[1]<-10
	k<-0
	diff<-tol+1

	while ( (diff>tol) & (k<maxiter) )
	{
		k<-k+1

		V<-diag(1,m)
		for (i in 1:m) {V[i,i]<-(sigma2.u.stim[k]+vardir[i,1])}

		Vinv<-solve(V)

		BETA<-solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%Vinv%*%ydir[,1]
		P<-Vinv-(Vinv%*%Xpop%*%solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%Vinv) #P matrix
		sdev<-(-0.5)*sum(diag(P))+((0.5)*t(ydir[,1])%*%P%*%P%*%ydir[,1])
		Idev<-((0.5)*(sum(diag(P%*%P))))^(-1)
		sigma2.u.stim[k+1]<-sigma2.u.stim[k]+Idev*sdev
		diff<-abs(sigma2.u.stim[k+1]-sigma2.u.stim[k])
		if (k>100) {diff.S=0.00001}
	}

	if (sigma2.u.stim[k+1]<0) 
		sigma2uREML<-0 
	else
		sigma2uREML<-sigma2.u.stim[k+1]

#	sigma.sim.REML[w]<-sigma2uREML
	V<-diag(1,m)
	G<-diag(1,m)*sigma2uREML
	for (i in 1:m) 
		V[i,i]<-(sigma2uREML+vardir[i,1])
               
	Vinv<-solve(V)
 
	Bstim<-solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop)%*%Vinv%*%ydir[,1]
	m1<-diag(1,m)
	thetaEBLUPREML<-Xpop%*%Bstim+m1%*%G%*%Vinv%*%(ydir[,1]-(Xpop%*%Bstim))
	randeff<-m1%*%G%*%Vinv%*%(ydir[,1]-(Xpop%*%Bstim))#Estimate of the random effects
	varbeta<-solve(t(Xpop)%*%solve(V)%*%Xpop)

	#to estimate MSE

	g1REML<-diag((G-G%*%Vinv%*%G))


	g2REML<-matrix(0,m,1)
	for (i in 1:m) 
	{
		m1<-matrix(0,m,1)
		m1[i]<-1
		g2REML[i]<-(Xpop[i,]-t(m1)%*%G%*%Vinv%*%Xpop)%*%solve(t(Xpop)%*%Vinv%*%Xpop)%*%t(Xpop[i,]-t(m1)%*%G%*%Vinv%*%Xpop)
	}

	Idev<-((0.5)*(sum(diag(P%*%P))))^(-1)
	g3REML<-matrix(0,m,1)
	for (i in 1:m) 
	{
		m1<-matrix(0,m,1)
		m1[i]<-1
		g3REML[i]<-(t(m1)%*%(Vinv+G%*%((-1)*Vinv%*%Vinv))%*%V%*%t((t(m1)%*%(Vinv+G%*%((-1)*Vinv%*%Vinv)))))*Idev
	}


	msestimREML<-g1REML+g2REML+2*g3REML



#	list(beta=Bstim, betasig=NULL, EBLUP=thetaEBLUPREML,g1=g1REML, 
#		g2=g2REML, g3=g3REML, MSE=msestimREML)
	list(EBLUP=thetaEBLUPREML, beta=Bstim, betasig=NULL, 
  sigma2u=sigma2.u.stim[k+1], g1=g1REML, g2=g2REML, 
  g3=g3REML, mse=msestimREML, randeff=randeff, varbeta=varbeta)
}
