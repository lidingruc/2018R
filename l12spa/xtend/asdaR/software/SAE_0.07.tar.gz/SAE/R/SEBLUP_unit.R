

##Z is the incidence matrix
#Z=matrix(0,nc,m)
#
#t=0
#for (j in 1:m) {for(i in 1:dimc[j]){t<-t+1
#                                Z[t,j]<-1}}


##XS is the auxiliary information matrix
#S[,2] the response variable vector
#XS<-cbind(rep(1,nc),xcamp[,1])

SEBLUP.unit<-function(S, XS, Xpop, Z, m, W, tol=10e-5, maxiter=50, 
  method="ML")
{
        res<-switch(method,
                ML = SEBLUP.unit.ML(S, XS, Xpop, Z, m, W, tol, maxiter),
                REML = SEBLUP.unit.REML(S, XS, Xpop, Z, m, W, tol, maxiter)
        )

        if(is.null(res))
                print("Method should be ML or REML\n")

        return(res)
}


SEBLUP.unit.ML<-function(S, XS, Xpop, Z, m, W, tol, maxiter)
{
########################
#Stima di sigma2u e rho#
########################

nc<-dim(S)[1]
I<-diag(1,m)


#This is VERY slow and computationally expensive in this case
ottimo<-constrOptim(c(0.7,100,1),logl.unit,grr.unit,method="Nelder-Mead",
  ui=rbind(c(-1,0,0),c(1,0,0),c(0,1,0),c(0,0,1)),ci=c(-1,-1,0,0))

#Some sensible? initial values
#ottimo<-list(par=c(.5,1,1))

#Initial values of some variables
rho.stim.S<-0
sigma2.u.stim.S<-0
sigma.e.stim.S<-0
sigma2.u.stim.S[1]<-ottimo$par[2]
rho.stim.S[1]<-ottimo$par[1]
sigma.e.stim.S[1]<-ottimo$par[3]


k<-0
diff.S<-1

##########
#Stima ML#
##########

while ((diff.S>tol) && (k<maxiter))
{k<-k+1

solvIrhoW2<-solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))

B<-Z%*%solvIrhoW2%*%t(Z)
C<-sigma2.u.stim.S[k]*Z%*%((-1)*solvIrhoW2)%*%(-2*W+2*rho.stim.S[k]*W%*%t(W))%*%solvIrhoW2%*%t(Z)

Inn<-diag(1,nc)

V<-matrix(0,nc,nc)
V<-Z%*%(sigma2.u.stim.S[k]*( solvIrhoW2 ))%*%t(Z)+sigma.e.stim.S[k]*Inn
Vinv<-solve(V)

b.s<-solve(t(XS)%*%Vinv%*%XS)%*%t(XS)%*%Vinv%*%S[,2]
s<-matrix(0,3,1)
Idev<-matrix(0,3,3)

VinvB<-Vinv%*%B
VinvInn<-Vinv%*%Inn
VinvC<-Vinv%*%C


#??
s[1,1]<-((-0.5)*sum(diag(VinvB)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(VinvB%*%Vinv)%*%(S[,2]-XS%*%b.s)))  
s[2,1]<-((-0.5)*sum(diag(VinvInn)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(VinvInn%*%Vinv)%*%(S[,2]-XS%*%b.s)))
s[3,1]<-((-0.5)*sum(diag(VinvC)))+((0.5)*(t(S[,2]-XS%*%b.s)%*%(VinvC%*%Vinv)%*%(S[,2]-XS%*%b.s)))  

#Partial derivatives?
Idev[1,1]<-(0.5)*sum(diag(VinvB%*%VinvB))
Idev[1,2]<-(0.5)*sum(diag(VinvB%*%VinvInn))
Idev[1,3]<-(0.5)*sum(diag(VinvB%*%VinvC))
Idev[2,1]<-(0.5)*sum(diag(VinvInn%*%VinvB))
Idev[2,2]<-(0.5)*sum(diag(VinvInn%*%VinvInn))
Idev[2,3]<-(0.5)*sum(diag(VinvInn%*%VinvC))
Idev[3,1]<-(0.5)*sum(diag(VinvC%*%VinvB))
Idev[3,2]<-(0.5)*sum(diag(VinvC%*%VinvInn))
Idev[3,3]<-(0.5)*sum(diag(VinvC%*%VinvC))

#Parameter estimates in this iteration
par.stim<-matrix(0,3,1)
par.stim[1,1]<-sigma2.u.stim.S[k]
par.stim[2,1]<-sigma.e.stim.S[k]
par.stim[3,1]<-rho.stim.S[k]

#Final estimates
stime.fin<-matrix(0,3,1)
stime.fin<-par.stim+solve(Idev)%*%s

sigma2.u.stim.S[k+1]<-stime.fin[1,1]
sigma.e.stim.S[k+1]<-stime.fin[2,1]
rho.stim.S[k+1]<-stime.fin[3,1]
diff.S<-abs(stime.fin[3,1]-par.stim[3,1])

}

solvIrhoW2<-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))

V<-Z%*%(sigma2.u.stim.S[k+1]*(solvIrhoW2))%*%t(Z)+sigma.e.stim.S[k+1]*Inn
Vinv<-solve(V)

G<-sigma2.u.stim.S[k+1]*solvIrhoW2                

tXSVinv<-t(XS)%*%Vinv
Bstim<-solve(tXSVinv%*%XS)%*%tXSVinv%*%S[,2]

randeff<-I%*%G%*%t(Z)%*%solve(V)%*%(S[,2]-(XS%*%Bstim))
thetaEBLUPsp<-Xpop%*%Bstim+randeff #I%*%G%*%t(Z)%*%solve(V)%*%(S[,2]-(XS%*%Bstim))
varbeta<-solve(tXSVinv%*%XS)


#Compute MSE

#G1
g1sp<-matrix(0,m,1)
for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
                 g1sp[i]<-t(m1)%*%(G-G%*%t(Z)%*%solve(V)%*%Z%*%G)%*%m1}
#G2
g2sp<-matrix(0,m,1)
for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
                 g2sp[i]<-(Xpop[i,]-t(m1)%*%G%*%t(Z)%*%solve(V)%*%XS)%*%solve(t(XS)%*%solve(V)%*%XS)%*%t(Xpop[i,]-t(m1)%*%G%*%t(Z)%*%solve(V)%*%XS)}


#B=Z%*%solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))%*%t(Z)
#C=sigma2.u.stim.S[k+1]*Z%*%(-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))%*%(-2*W+2*rho.stim.S[k+1]*W%*%t(W))%*%solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))))%*%t(Z)
#Inn=diag(1,183)
#Idev[1,1]<-(0.5)*sum(diag((solve(V)%*%B%*%solve(V)%*%B)))
#Idev[1,2]<-(0.5)*sum(diag((solve(V)%*%B%*%solve(V)%*%Inn)))
#Idev[1,3]<-(0.5)*sum(diag((solve(V)%*%B%*%solve(V)%*%C)))
#Idev[2,1]<-(0.5)*sum(diag((solve(V)%*%Inn%*%solve(V)%*%B)))
#Idev[2,2]<-(0.5)*sum(diag((solve(V)%*%Inn%*%solve(V)%*%Inn)))
#Idev[2,3]<-(0.5)*sum(diag((solve(V)%*%Inn%*%solve(V)%*%C)))
#Idev[3,1]<-(0.5)*sum(diag((solve(V)%*%C%*%solve(V)%*%B)))
#Idev[3,2]<-(0.5)*sum(diag((solve(V)%*%C%*%solve(V)%*%Inn)))
#Idev[3,3]<-(0.5)*sum(diag((solve(V)%*%C%*%solve(V)%*%C)))

#G3
g3sp<-matrix(0,m,1)
g3spgrad<-matrix(0,3,183)
for (i in 1:m) {
m1<-matrix(0,m,1)
                  m1[i]<-1
                  A<-(I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))
                  AA<-2*rho.stim.S[k+1]*(W%*%t(W))-2*W
                  g3spgrad[1,]<-t(m1)%*%(solve(A)%*%t(Z)%*%solve(V)+G%*%t(Z)%*%((-1)*solve(V)%*%Z%*%solve(A)%*%t(Z)%*%solve(V)))
                  g3spgrad[2,]<-t(m1)%*%(G%*%t(Z)%*%((-1)*solve(V)%*%Inn%*%solve(V)))
                  g3spgrad[3,]<-t(m1)%*%(((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%t(Z)%*%solve(V))+G%*%t(Z)%*%((-1)*solve(V)%*%Z%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%t(Z)%*%solve(V)))
                  g3sp[i]<-sum(diag(g3spgrad%*%V%*%t(g3spgrad)%*%solve(Idev)))}

bdist<-matrix(0,3,1)
btr<-matrix(0,3,1)
gradg1sp<-matrix(0,3,1)
distorsionesp<-matrix(0,m,1)
D<-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))
E<-sigma2.u.stim.S[k+1]*((-1)*D%*%(2*rho.stim.S[k+1]*(W%*%t(W))-2*W)%*%D)
for (i in 1:m) 
{
	m1<-matrix(0,m,1)
                 m1[i]<-1
                 gradg1sp[1,]<-t(m1)%*%(D-((D%*%t(Z)%*%solve(V)%*%Z%*%G)+(G%*%t(Z)%*%((-1)*solve(V)%*%B%*%solve(V))%*%Z%*%G)+(G%*%t(Z)%*%solve(V)%*%Z%*%D)))%*%m1
                 gradg1sp[2,]<-t(m1)%*%((-1)*G%*%t(Z)%*%((-1)*solve(V)%*%Inn%*%solve(V))%*%Z%*%G)%*%m1
                 gradg1sp[3,]<-t(m1)%*%(E-((E%*%t(Z)%*%solve(V)%*%Z%*%G)+(G%*%t(Z)%*%((-1)*solve(V)%*%C%*%solve(V))%*%Z%*%G)+(G%*%t(Z)%*%solve(V)%*%Z%*%E)))%*%m1
                 btr[1,]<-sum(diag(solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%((-1)*solve(V)%*%B%*%solve(V))%*%XS))
                 btr[2,]<-sum(diag(solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%((-1)*solve(V)%*%Inn%*%solve(V))%*%XS))
                 btr[3,]<-sum(diag(solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%((-1)*solve(V)%*%C%*%solve(V))%*%XS))
                 bdist<-(1/(m*2))*(solve(Idev)%*%btr)
                 distorsionesp[i,1]<-t(bdist)%*%gradg1sp
}

msestimsp<-g1sp-distorsionesp+g2sp+2*g3sp


#Return results
list(SEBLUP=thetaEBLUPsp, beta=Bstim, sigma2u=sigma2.u.stim.S[k+1],
#  rho=rho.stim.S[k+1], g1=g1sp, g2=g2sp, g3=g3sp, mse=msestimsp)
  sigma2.e=sigma.e.stim.S[k+1], rho=rho.stim.S[k+1], g1=g1sp, g2=g2sp, 
  g3=g3sp, mse=msestimsp, randeff=randeff, varbeta=varbeta, 
  varsigmarho=solve(Idev))
}



SEBLUP.unit.REML<-function(S, XS, Xpop, Z, m, W, tol, maxiter)
{

#REML
nc<-dim(S)[1]
I<-diag(1,m)

ottimo<-constrOptim(c(0.7,100,1),logl.unit,grr.unit,method="Nelder-Mead",
  ui=rbind(c(-1,0,0),c(1,0,0),c(0,1,0),c(0,0,1)),ci=c(-1,-1,0,0))



#Initial values of some variables
rho.stim.S<-0
sigma2.u.stim.S<-0
sigma.e.stim.S<-0
sigma2.u.stim.S[1]<-ottimo$par[2]
rho.stim.S[1]<-ottimo$par[1]
sigma.e.stim.S[1]<-ottimo$par[3]

k<-0
diff.S<-1
while ( (diff.S>tol) && (k<maxiter) )
{k<-k+1
B=Z%*%solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))%*%t(Z)
C=sigma2.u.stim.S[k]*Z%*%((-1)*solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))%*%(-2*W+2*rho.stim.S[k]*W%*%t(W))%*%solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W))))%*%t(Z)
Inn=diag(1,nc)
V<-matrix(0,nc,nc)
V<-Z%*%(sigma2.u.stim.S[k]*(solve((I-rho.stim.S[k]*W)%*%(I-rho.stim.S[k]*t(W)))))%*%t(Z)+sigma.e.stim.S[k]*Inn
P=solve(V)-solve(V)%*%XS%*%solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)
b.s<-solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)%*%S[,2]
s<-matrix(0,3,1)
Idev<-matrix(0,3,3)
s[1,1]<-((-0.5)*sum(diag(P%*%B)))+((0.5)*t(S[,2])%*%P%*%B%*%P%*%S[,2])
s[2,1]<-((-0.5)*sum(diag(P%*%Inn)))+((0.5)*t(S[,2])%*%P%*%Inn%*%P%*%S[,2])
s[3,1]<-((-0.5)*sum(diag(P%*%C)))+((0.5)*t(S[,2])%*%P%*%C%*%P%*%S[,2])
Idev[1,1]<-(0.5)*sum(diag((P%*%B%*%P%*%B)))
Idev[1,2]<-(0.5)*sum(diag((P%*%B%*%P%*%Inn)))
Idev[1,3]<-(0.5)*sum(diag((P%*%B%*%P%*%C)))
Idev[2,1]<-(0.5)*sum(diag((P%*%Inn%*%P%*%B)))
Idev[2,2]<-(0.5)*sum(diag((P%*%Inn%*%P%*%Inn)))
Idev[2,3]<-(0.5)*sum(diag((P%*%Inn%*%P%*%C)))
Idev[3,1]<-(0.5)*sum(diag((P%*%C%*%P%*%B)))
Idev[3,2]<-(0.5)*sum(diag((P%*%C%*%P%*%Inn)))
Idev[3,3]<-(0.5)*sum(diag((P%*%C%*%P%*%C)))
par.stim<-matrix(0,3,1)
par.stim[1,1]<-sigma2.u.stim.S[k]
par.stim[2,1]<-sigma.e.stim.S[k]
par.stim[3,1]<-rho.stim.S[k]
stime.fin<-matrix(0,3,1)
stime.fin<-par.stim+solve(Idev)%*%s
sigma2.u.stim.S[k+1]<-stime.fin[1,1]
sigma.e.stim.S[k+1]<-stime.fin[2,1]
rho.stim.S[k+1]<-stime.fin[3,1]
diff.S<-abs(stime.fin[3,1]-par.stim[3,1])
if (k>50) diff.S=0.0000001}

V<-Z%*%(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))%*%t(Z)+sigma.e.stim.S[k+1]*Inn
G<-(sigma2.u.stim.S[k+1]*(solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))))        
Bstim<-solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)%*%S[,2]
m1<-diag(1,m)

randeff<-m1%*%G%*%t(Z)%*%solve(V)%*%(S[,2]-(XS%*%Bstim))
thetaEBLUPspR<-Xpop%*%Bstim+randeff #m1%*%G%*%t(Z)%*%solve(V)%*%(S[,2]-(XS%*%Bstim))
varbeta<-solve(t(XS)%*%solve(V)%*%XS)
#Compute MSE

#G1
g1spREML<-matrix(0,m,1)
for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
                 g1spREML[i]<-t(m1)%*%(G-G%*%t(Z)%*%solve(V)%*%Z%*%G)%*%m1}


#G2
g2spREML<-matrix(0,m,1)
for (i in 1:m) {m1<-matrix(0,m,1)
                 m1[i]<-1
                 g2spREML[i]<-(Xmedio[i,]-t(m1)%*%G%*%t(Z)%*%solve(V)%*%XS)%*%solve(t(XS)%*%solve(V)%*%XS)%*%t(Xmedio[i,]-t(m1)%*%G%*%t(Z)%*%solve(V)%*%XS)}




#B=Z%*%solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))%*%t(Z)
#C=sigma2.u.stim.S[k+1]*Z%*%(-solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W)))%*%(-2*W+2*rho.stim.S[k+1]*W%*%t(W))%*%solve((I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))))%*%t(Z)
#Inn=diag(1,183)
#P=solve(V)-solve(V)%*%XS%*%solve(t(XS)%*%solve(V)%*%XS)%*%t(XS)%*%solve(V)
#Idev=matrix(0,3,3)
#Idev[1,1]<-(0.5)*sum(diag((P%*%B%*%P%*%B)))
#Idev[1,2]<-(0.5)*sum(diag((P%*%B%*%P%*%Inn)))
#Idev[1,3]<-(0.5)*sum(diag((P%*%B%*%P%*%C)))
#Idev[2,1]<-(0.5)*sum(diag((P%*%Inn%*%P%*%B)))
#Idev[2,2]<-(0.5)*sum(diag((P%*%Inn%*%P%*%Inn)))
#Idev[2,3]<-(0.5)*sum(diag((P%*%Inn%*%P%*%C)))
#Idev[3,1]<-(0.5)*sum(diag((P%*%C%*%P%*%B)))
#Idev[3,2]<-(0.5)*sum(diag((P%*%C%*%P%*%Inn)))
#Idev[3,3]<-(0.5)*sum(diag((P%*%C%*%P%*%C)))

g3spREML<-matrix(0,m,1)
g3spgrad<-matrix(0,3,183)
for (i in 1:m) {m1<-matrix(0,m,1)
                  m1[i]<-1
                  A<-(I-rho.stim.S[k+1]*W)%*%(I-rho.stim.S[k+1]*t(W))
                  AA<-2*rho.stim.S[k+1]*(W%*%t(W))-2*W
                  g3spgrad[1,]<-t(m1)%*%(solve(A)%*%t(Z)%*%solve(V)+G%*%t(Z)%*%((-1)*solve(V)%*%Z%*%solve(A)%*%t(Z)%*%solve(V)))
                  g3spgrad[2,]<-t(m1)%*%(G%*%t(Z)%*%((-1)*solve(V)%*%Inn%*%solve(V)))
                  g3spgrad[3,]<-t(m1)%*%(((sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%t(Z)%*%solve(V))+G%*%t(Z)%*%((-1)*solve(V)%*%Z%*%(sigma2.u.stim.S[k+1]*((-1)*solve(A)%*%(AA)%*%solve(A)))%*%t(Z)%*%solve(V)))
                  g3spREML[i]<-sum(diag(g3spgrad%*%V%*%t(g3spgrad)%*%solve(Idev)))}

msestimspREML<-0
msestimspREML<-g1spREML+g2spREML+2*g3spREML



#Return results
list(SEBLUP=thetaEBLUPspR, beta=Bstim, sigma2u=sigma2.u.stim.S[k+1],
#  rho=rho.stim.S[k+1], g1=g1sp, g2=g2sp, g3=g3sp, mse=msestimsp)
  sigma2.e=sigma.e.stim.S[k+1], rho=rho.stim.S[k+1], g1=g1spREML, g2=g2spREML, 
  g3=g3spREML, mse=msestimspREML, randeff=randeff, varbeta=varbeta,
  varsigmarho=solve(Idev))

}

