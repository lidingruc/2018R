### Name: SEBLUP.area
### Title: Spatial EBLUP estimator for small areas
### Aliases: SEBLUP.area SEBLUP.area.ML SEBLUP.area.REML
### Keywords: models

### ** Examples

#Load data
data(seblup)

#SEBLUP using ML estimation
seblupml<-SEBLUP.area(ydir1, Xpop, vardir, m, W)

#SEBLUP using ML estimation
seblupreml<-SEBLUP.area(ydir1, Xpop, vardir, m, W, method="REML")



