### Name: EBLUP
### Title: EBLUP estimator for small areas
### Aliases: EBLUP EBLUP.area EBLUP.area.ML EBLUP.area.REML
### Keywords: models

### ** Examples

#Load data
data(seblup)

#EBLUP using ML estimation
eblupml<-EBLUP.area(ydir1, Xpop, vardir, m)

#EBLUP using ML estimation
eblupreml<-EBLUP.area(ydir1, Xpop, vardir, m, method="REML")




