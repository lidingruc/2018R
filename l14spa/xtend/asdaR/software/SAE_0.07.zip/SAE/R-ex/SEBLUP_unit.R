### Name: SEBLUP.unit
### Title: Spatial EBLUP estimator for small areas
### Aliases: SEBLUP.unit SEBLUP.unit.ML SEBLUP.unit.REML
### Keywords: models

### ** Examples

## Not run: 
##D #Load data
##D data(seblup)
##D 
##D #EBLUP using ML estimation
##D seblupmlu<-SEBLUP.unit(S, XS, Xpop, ZS, m, W)
##D 
##D #EBLUP using ML estimation
##D seblupremlu<-SEBLUP.unit(S, XS, Xpop, ZS, m, W, method="REML")
## End(Not run)



